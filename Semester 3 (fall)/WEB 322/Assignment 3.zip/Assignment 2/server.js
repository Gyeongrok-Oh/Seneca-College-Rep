/********************************************************************************

* WEB322 – Assignment 03

*

* I declare that this assignment is my own work in accordance with Seneca's

* Academic Integrity Policy:

*

* https://www.senecacollege.ca/about/policies/academic-integrity-policy.html

*

* Name: Gyeongrok oh Student ID: 119140226 Date:Oct 24 2023

*

* Published URL:

*

********************************************************************************/
const express = require('express');
const legoData = require('./modules/legoSets');
const path = require('path');
const app = express();

const port = process.env.PORT || 8080; // Set the port for your server

// Middleware to wait for legoData initialization before starting the server
app.use(async (req, res, next) => {
  try {
    await legoData.initialize();
    next(); // Proceed to the next middleware/route
  } catch (error) {
    res.status(500).send('Error initializing Lego data');
  }
});

app.use(express.static(__dirname + '/public'));
 
// Update route for homepage

app.get('/', (req, res) => {

  res.sendFile(path.join(__dirname, "/views/home.html"));

});

// Update route for about

app.get('/about', (req, res) => {

  res.sendFile(path.join(__dirname, "/views/about.html"));

});


app.get('/lego/sets', (req, res) => {
  const theme = req.query.theme; // query parameter

  if (theme) {
    legoData.getSetsByTheme(theme)
      .then(sets => {
        if (sets.length > 0) {
          res.json(sets);
        } else {
          res.status(404).send("No sets found with the specified theme");
        }
      })
      .catch(error => {
        res.status(404).send(error);
      });
  } else {
    legoData.getAllSets()
      .then(sets => {
        if (sets.length > 0) {
          res.json(sets);
        } else {
          res.status(404).send("Sets not available");
        }
      })
      .catch(error => {
        res.status(404).send(error);
      });
  }
});


app.get('/lego/sets/:set_num', (req, res) => {
  const setNum = req.params.set_num;

  legoData.getSetByNum(setNum)
    .then(set => {
      if (set) {
        res.json(set);
      } else {
        res.status(404).send('Lego set not found');
      }
    })
    .catch(error => {
      res.status(404).send(error);
    });
});


// // Add support for a custom "404 error".

app.use((req, res) => {

  res.status(404).sendFile(path.join(__dirname, 'views', '404.html'));

});
// Start the server
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
